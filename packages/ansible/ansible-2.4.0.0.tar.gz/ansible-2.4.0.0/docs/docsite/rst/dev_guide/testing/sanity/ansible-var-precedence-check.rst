Sanity Tests » ansible-var-precedence-check
===========================================

Check the order of precedence for Ansible variables against :ref:`variable_precedence`.
