Sanity Tests » empty-init
=========================

The ``__init__.py`` files under the following directories must be empty:

- ``lib/ansible/modules/``
- ``test/units/``
